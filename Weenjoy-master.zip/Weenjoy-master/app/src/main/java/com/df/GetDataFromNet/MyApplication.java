package com.df.GetDataFromNet;

import android.app.Application;

/**
 * Created by asus88 on 2016/4/6.
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }


}
